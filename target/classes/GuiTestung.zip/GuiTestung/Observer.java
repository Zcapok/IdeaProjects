package GuiTestung;

public interface Observer {
    void update();
}

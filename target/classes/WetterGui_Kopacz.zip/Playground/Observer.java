package Playground;

public interface Observer {
    public abstract void update();
}
